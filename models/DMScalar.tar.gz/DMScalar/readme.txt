DMScalar: Scalar mediated Dark Matter
Kristian Hahn - Northwestern Univ. - 02/15
=============================================

* Free parameters are Mchi, Mphi, gDM and gqq.  

* Mediator width is calculated from the partial widths into SM fermions and the chi DM fermions.

* The free parameters have corresponding symbols (eg: X_gqq_X) in the parameters_template.py file that can be replaced programmatically.

